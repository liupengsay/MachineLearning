

import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error
from sklearn.model_selection import KFold

train = pd.read_csv("preprocess/baseline_train.csv")
test = pd.read_csv("preprocess/baseline_test.csv")

label = "target"
features = train.columns.tolist()
features.remove("card_id")
features.remove("target")
featureSelect = features[:]
# 去掉缺失值比例超过0.99的
for fea in features:
    if train[fea].isnull().sum()/train.shape[0] >= 0.99:
        featureSelect.remove(fea)
corr = []
for fea in featureSelect:
    corr.append(abs(train[[fea, label]].fillna(0).corr().values[0][1]))

se = pd.Series(corr, index=featureSelect).sort_values(ascending=False)
featureSelect = se[se>=0.005].index.tolist()

def RandomForest_cv(cols):
    clf = RandomForestRegressor(
        n_estimators=30,
        criterion="mse",
        max_depth=5,
        min_samples_split=2,
        min_samples_leaf=1,
        min_weight_fraction_leaf=0.,
        max_features="auto",
        max_leaf_nodes=None,
        min_impurity_decrease=0.,
        min_impurity_split=None,
        bootstrap=True,
        oob_score=False,
        n_jobs=4,
        random_state=2020,
        verbose=0,
        warm_start=False
    )
    cv_score = []
    kf = KFold(n_splits=5, random_state=2020, shuffle=True)
    prediction = 0
    for train_part_index, eval_index in kf.split(train[cols], train[label]):
        clf.fit(train[cols].fillna(0).loc[train_part_index], train[label].loc[train_part_index])
        eval_pre = clf.predict(train[cols].fillna(0).loc[eval_index])
        prediction += clf.predict(test[cols].fillna(0))
        score = np.sqrt(mean_squared_error(train[label].loc[eval_index], eval_pre))
        print(score)
        cv_score.append(score)
    print(cv_score)
    return [p/5 for p in list(prediction)], sum(cv_score)/5

_, score = RandomForest_cv(features)
print(score)
# 3.7623605333016554
prediction, score = RandomForest_cv(featureSelect)
print(score)
# 3.7613166794592003
submission = test[["card_id"]].copy()
submission["target"] = prediction
submission.to_csv("result/RF_FeatureSelect_submission.csv", index=False)
pd.Series(featureSelect).to_csv("preprocess/RF_select_feature.csv", index=False)