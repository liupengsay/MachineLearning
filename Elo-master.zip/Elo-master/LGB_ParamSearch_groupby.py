import numpy as np
import pandas as pd
import lightgbm as lgb
from sklearn.model_selection import KFold
from sklearn.metrics import mean_squared_error
from hyperopt import hp, fmin, tpe
from numpy.random import RandomState
debug = False
NROWS = 10000 if debug else None
train = pd.read_csv("preprocess/train_groupby.csv", nrows=NROWS)

test = pd.read_csv("preprocess/test_groupby.csv", nrows=NROWS)
label = "target"
features = train.columns.tolist()
features.remove('card_id')
features.remove('target')
train_data = lgb.Dataset(train[features], train[label], silent=True)

def params_append(params):
    params['objective'] = 'regression'
    params['metric'] = 'rmse'
    params['bagging_seed'] = 2020
    return params
def hyperopt_objective(params):
    params = params_append(params)
    print(params)
    res = lgb.cv(params, train_data, 1000,
                 nfold=5,
                 stratified=False,
                 shuffle=True,
                 metrics='rmse',
                 early_stopping_rounds=20,
                 verbose_eval=False,
                 show_stdv=False,
                 seed=2020)
    return min(res['rmse-mean'])

def train_predict(params):
    params = params_append(params)
    kf = KFold(n_splits=5, random_state=2020, shuffle=True)
    prediction = 0
    cv_score = []
    ESR = 30
    NBR = 10000
    VBE = 50
    for train_part_index, eval_index in kf.split(train[features], train[label]):
        # 模型训练
        train_part = lgb.Dataset(train[features].loc[train_part_index],
                                 train[label].loc[train_part_index])
        eval = lgb.Dataset(train[features].loc[eval_index],
                           train[label].loc[eval_index])
        bst = lgb.train(params, train_part, num_boost_round=NBR,
                        valid_sets=[train_part, eval],
                        valid_names=['train', 'valid'],
                        early_stopping_rounds=ESR, verbose_eval=VBE)
        prediction += bst.predict(test[features])
        eval_pre = bst.predict(train[features].loc[eval_index])
        score = np.sqrt(mean_squared_error(train[label].loc[eval_index].values, eval_pre))
        cv_score.append(score)
    print(cv_score, sum(cv_score) / 5)
    submission = test[["card_id"]].copy()
    submission["target"] = [p / 5 for p in list(prediction)]
    submission.to_csv("result/LGB_ParamSearch_groupby_submission.csv", index=False)
    return
params_space = {
    'learning_rate': hp.uniform('learning_rate', 1e-2, 5e-1),
    'bagging_fraction': hp.uniform('bagging_fraction', 0.5, 1),
    'feature_fraction': hp.uniform('feature_fraction', 0.5, 1),
    'num_leaves': hp.choice('num_leaves', list(range(10, 300, 10))),
    'reg_alpha': hp.randint('reg_alpha', 0, 10),
    'reg_lambda': hp.uniform('reg_lambda', 0, 10),
    'bagging_freq': hp.randint('bagging_freq', 1, 10),
    'min_child_samples': hp.choice('min_child_samples', list(range(1, 30, 5)))
}


# params_best = fmin(
#     hyperopt_objective,
#     space=params_space,
#     algo=tpe.suggest,
#     max_evals=50,
#     rstate=RandomState(2020))
# print(params_best)
# params_best = {'bagging_fraction': 0.808224077076037, 'bagging_freq': 5, 'feature_fraction': 0.6048957762009759, 'learning_rate': 0.011040874768079093, 'min_child_samples': 5, 'num_leaves': 2, 'reg_alpha': 3, 'reg_lambda': 3.8014667728190368, 'objective': 'regression', 'metric': 'rmse', 'bagging_seed': 2020}
# print(hyperopt_objective(params_best))
params_best = {'bagging_fraction': 0.7426152821881745, 'bagging_freq': 1, 'feature_fraction': 0.9412130227040326, 'learning_rate': 0.03633345947324272, 'min_child_samples': 5, 'num_leaves': 27, 'reg_alpha': 9, 'reg_lambda': 3.0248148879676515, 'objective': 'regression', 'metric': 'rmse', 'bagging_seed': 2020}
train_predict(params_best)