import pandas as pd
import numpy as np
from sklearn.model_selection import StratifiedKFold
import lightgbm as lgb
from sklearn.metrics import precision_score

# reduce memory
def reduce_mem_usage(df, verbose=True):
    numerics = ['int16', 'int32', 'int64', 'float16', 'float32', 'float64']
    start_mem = df.memory_usage().sum() / 1024**2
    for col in df.columns:
        col_type = df[col].dtypes
        if col_type in numerics:
            c_min = df[col].min()
            c_max = df[col].max()
            if str(col_type)[:3] == 'int':
                if c_min > np.iinfo(np.int8).min and c_max < np.iinfo(np.int8).max:
                    df[col] = df[col].astype(np.int8)
                elif c_min > np.iinfo(np.int16).min and c_max < np.iinfo(np.int16).max:
                    df[col] = df[col].astype(np.int16)
                elif c_min > np.iinfo(np.int32).min and c_max < np.iinfo(np.int32).max:
                    df[col] = df[col].astype(np.int32)
                elif c_min > np.iinfo(np.int64).min and c_max < np.iinfo(np.int64).max:
                    df[col] = df[col].astype(np.int64)
            else:
                if c_min > np.finfo(np.float16).min and c_max < np.finfo(np.float16).max:
                    df[col] = df[col].astype(np.float16)
                elif c_min > np.finfo(np.float32).min and c_max < np.finfo(np.float32).max:
                    df[col] = df[col].astype(np.float32)
                else:
                    df[col] = df[col].astype(np.float64)

    end_mem = df.memory_usage().sum() / 1024**2
    print('Memory usage after optimization is: {:.2f} MB'.format(end_mem))
    print('Decreased by {:.1f}%'.format(100 * (start_mem - end_mem) / start_mem))

    return df

def get_dict_feature(feature, filename):
    print(filename, "字典特征提取")
    fr = open("data/" + filename + "/click_log.csv", "r")
    ad =  pd.read_csv("data/" + filename + "/ad.csv")
    ad = ad.replace("\\N", np.nan).fillna(-1).astype(str)
    ad_cols = ad.columns.tolist()
    ads = {}
    for va in ad.values:
        ads[va[0]] = {}
        for i in range(1, len(ad_cols)):
            ads[va[0]][ad_cols[i]] = va[i]

    head = fr.readline().strip("\n").split(",")
    print(head)
    line = fr.readline().strip("\n").split(",")
    while line != [""]:
        [day, user_id, creative_id, click_times] = line
        click_times = int(click_times)
        if feature.get(user_id, []) == []:
            feature[user_id] = {}

        col_name = "time_" + day + "_click_times"
        feature[user_id][col_name] = feature[user_id].get(col_name, 0) + click_times

        # col_name = "creative_id_" + creative_id + "_click_times"
        # feature[user_id][col_name] = feature[user_id].get(col_name, 0) + click_times

        col_name = "click_times"
        feature[user_id][col_name] = feature[user_id].get(col_name, 0) + click_times

        for fea in ad_cols[2:]:
            col_name = fea + ads[creative_id][fea] + "_click_times"
            feature[user_id][col_name] = feature[user_id].get(col_name, 0) + click_times
        line = fr.readline().strip("\n").split(",")
    fr.close()
    return feature

def get_dict_feature_plus(feature, threshold):
    dimension = ['time', 'product_id', 'product_category',
        'advertiser_id', 'industry'] # 'creative_id', 'ad_id',

    # print("横向字典特征二次提取")
    # for user, _ in feature.items():
    #     cols = list(feature[user].keys())
    #     for fea in dimension:
    #         col_name = fea + '_nunique'
    #         feature[user][col_name] = len([col for col in cols if fea in col])
    #     for col in cols:
    #         if '_click_times' in col:
    #             feature[user][col + '_ratio'] = feature[user][col]/feature[user]['click_times']
    #
    count = {}
    for user, _ in feature.items():
        cols = list(feature[user].keys())
        for col in cols:
            count[col] = count.get(col, 0) + 1

    lower = len(feature.keys())*threshold
    print("过滤前总特征数", len(count.keys()), \
          "过滤后总特征数", len([key for key in count.keys() if count[key] >= lower]))
    for user, _ in feature.items():
        cols = list(feature[user].keys())
        for col in cols:
            if count[col] < lower:
                del feature[user][col]
    return feature

def get_dataframe_train(feature):
    df = pd.DataFrame(feature).T.reset_index()
    df.columns = ['user_id'] + df.columns.tolist()[1: ]
    df["user_id"] = df["user_id"].astype(np.int64)
    user = pd.read_csv("data/train_preliminary/user.csv")
    df = pd.merge(df, user, how='left', on='user_id').fillna(0)
    print("训练集宽表规格", df.shape)
    df.to_csv("preprocess/train_feature.csv", index=False)
    return df.columns.tolist()

def get_dataframe_test(feature):
    df = pd.DataFrame(feature).T.reset_index()
    df.columns = ['user_id'] + df.columns.tolist()[1: ]
    df["user_id"] = df["user_id"].astype(np.int64)
    print("测试集宽表规格", df.shape)
    df.to_csv("preprocess/test_feature.csv", index=False)
    return

def get_dict_feature_test(features, filename):
    select = {}
    for fea in features:
        select[fea] = 1
    feature = {}
    print(filename, "字典特征提取")
    fr = open("data/" + filename + "/click_log.csv", "r")
    ad =  pd.read_csv("data/" + filename + "/ad.csv")
    ad = ad.replace("\\N", np.nan).fillna(-1).astype(str)
    ad_cols = ad.columns.tolist()
    ads = {}
    for va in ad.values:
        ads[va[0]] = {}
        for i in range(1, len(ad_cols)):
            ads[va[0]][ad_cols[i]] = va[i]

    head = fr.readline().strip("\n").split(",")
    print(head)
    line = fr.readline().strip("\n").split(",")
    while line != [""]:
        [day, user_id, creative_id, click_times] = line
        click_times = int(click_times)
        if feature.get(user_id, []) == []:
            feature[user_id] = {}

        col_name = "time_" + day + "_click_times"
        if select.get(col_name, 0) == 1:
            feature[user_id][col_name] = feature[user_id].get(col_name, 0) + click_times

        # col_name = "creative_id_" + creative_id + "_click_times"
        # feature[user_id][col_name] = feature[user_id].get(col_name, 0) + click_times

        col_name = "click_times"
        if select.get(col_name, 0) == 1:
            feature[user_id][col_name] = feature[user_id].get(col_name, 0) + click_times

        for fea in ad_cols[2:]:

            col_name = fea + ads[creative_id][fea] + "_click_times"
            if select.get(col_name, 0) == 1:
                feature[user_id][col_name] = feature[user_id].get(col_name, 0) + click_times
        line = fr.readline().strip("\n").split(",")
    fr.close()
    return feature

def get_feature_all():

    filename = "train_preliminary"
    feature = get_dict_feature({}, filename)
    feature = get_dict_feature_plus(feature, 0.02)
    features = get_dataframe_train(feature)

    filename = "test"
    feature = get_dict_feature_test(features, filename)
    get_dataframe_test(feature)
    return

def train_predict(label, debug=False):
    NROWS = 10000 if debug else None
    train = reduce_mem_usage(pd.read_csv("preprocess/train_feature.csv", nrows=NROWS))
    test = reduce_mem_usage(pd.read_csv("preprocess/test_feature.csv", nrows=NROWS))
    features = test.columns.tolist()
    features.remove("user_id")
    num_class = train[label].nunique()
    train[label] = train[label]-1
    print(label, num_class)
    if num_class == 2:
        params_initial = {
            'num_leaves': 31,
            'learning_rate': 0.1,
            'boosting': 'gbdt',
            'min_child_samples': 20,
            'bagging_seed': 2020,
            'bagging_fraction': 0.7,
            'bagging_freq': 1,
            'feature_fraction': 0.7,
            'max_depth': -1,
            'metric': 'auc',
            'reg_alpha': 0,
            'reg_lambda': 1,
            'objective': 'binary'
        }
    else:
        params_initial = {
            'num_leaves': 31,
            'learning_rate': 0.1,
            'boosting': 'gbdt',
            'min_child_samples': 20,
            'bagging_seed': 2020,
            'bagging_fraction': 0.7,
            'bagging_freq': 1,
            'feature_fraction': 0.7,
            'max_depth': -1,
            'metric': 'multi_logloss',
            'reg_alpha': 0,
            'reg_lambda': 1,
            'objective': 'multiclass',
            'num_class': num_class
        }

    kf = StratifiedKFold(n_splits=5, random_state=2020, shuffle=True)
    prediction = 0
    cv_score = []
    ESR = 30
    NBR = 10000
    VBE = 50
    for train_part_index, eval_index in kf.split(train[features], train[label]):
        # 模型训练
        train_part = lgb.Dataset(train[features].loc[train_part_index],
                                 train[label].loc[train_part_index])
        eval = lgb.Dataset(train[features].loc[eval_index],
                           train[label].loc[eval_index])
        bst = lgb.train(params_initial, train_part, num_boost_round=NBR,
                        valid_sets=[train_part, eval],
                        valid_names=['train', 'valid'],
                        early_stopping_rounds=ESR, verbose_eval=False)
        prediction += bst.predict(test[features])
        eval_pre = bst.predict(train[features].loc[eval_index])
        if num_class == 2:
            eval_pre = pd.Series(eval_pre>=0.5).astype(int)
            score = precision_score(train[label].loc[eval_index].values, eval_pre)
        else:
            eval_pre = pd.DataFrame(eval_pre).apply(lambda x: x.idxmax(), axis=1)
            score = precision_score(train[label].loc[eval_index].values, eval_pre, average='micro')

        cv_score.append(score)
        print(score)
    print(cv_score, sum(cv_score) / 5)
    submission = test[["user_id"]].copy()

    if num_class == 2:
        submission[label] = pd.Series(prediction >= 2.5).astype(int)
    else:
        submission[label] = pd.DataFrame(prediction).apply(lambda x: x.idxmax(), axis=1)
    submission.to_csv("result/submission_"+label+".csv", index=False)
    return

if __name__ == "__main__":
    print("开始运行")
    # get_feature_all()
    train_predict('age', debug=False)
    train_predict('gender', debug=False)
