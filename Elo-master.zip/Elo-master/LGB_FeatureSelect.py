
import lightgbm as lgb
import pandas as pd
import numpy as np
from sklearn.model_selection import KFold
from sklearn.metrics import mean_squared_error

train = pd.read_csv('preprocess/baseline_train.csv')
test = pd.read_csv('preprocess/baseline_test.csv')
params_initial = {
       'num_leaves': 31,
       'learning_rate': 0.1,
       'boosting': 'gbdt',
       'min_child_samples': 20,
       'bagging_seed': 2020,
       'bagging_fraction': 0.7,
       'bagging_freq': 1,
       'feature_fraction': 0.7,
       'max_depth': -1,
       'metric': 'rmse',
       'reg_alpha': 0,
       'reg_lambda': 1,
       'objective': 'regression'
}
ESR = 30
NBR = 10000
VBE = 50
# 读取特征重要性
fse = pd.read_csv('result/baseline_feature_importance.csv')\
       .sort_values('importance', ascending=False)
cols = fse['feature'].values.tolist()
label = 'target'
lst = []
# for num in list(range(50, 200, 10))+[len(cols)]:
#        features = cols[:num]
#        data_train = lgb.Dataset(train[features], train[label], silent=True)
#        cv_results = lgb.cv(params_initial,
#                                    data_train,
#                                    num_boost_round=1000,
#                                    nfold=5,
#                                    stratified=False,
#                                    shuffle=True,
#                                    metrics='rmse',
#                                    early_stopping_rounds=50,
#                                    verbose_eval=False,
#                                    show_stdv=False,
#                                    seed=0)
#        lst.append(cv_results['rmse-mean'][-1])
#        print(num, 'best cv score:', cv_results['rmse-mean'][-1])
#        # 1404 best cv score: 3.711915479337742
# score_lst = pd.Series(lst[:-1], index=range(50, 200, 10))\
#        .sort_values()
# numFeatureSelect = score_lst.index[0]
# print(numFeatureSelect, score_lst.values[0])
numFeatureSelect = 190
# 190 3.70817358070979
features = cols[:numFeatureSelect]
pd.Series(features).to_csv('preprocess/lgb_select_feature.csv', index=False)

kf = KFold(n_splits=5, random_state=2020, shuffle=True)
prediction = 0
cv_score = []
for train_part_index, eval_index in kf.split(train[features], train[label]):
    # 模型训练
    train_part = lgb.Dataset(train[features].loc[train_part_index],
                             train[label].loc[train_part_index])
    eval = lgb.Dataset(train[features].loc[eval_index],
                             train[label].loc[eval_index])
    bst = lgb.train(params_initial, train_part, num_boost_round=NBR,
                    valid_sets=[train_part, eval],
                    valid_names=['train', 'valid'],
                    early_stopping_rounds=ESR, verbose_eval=VBE)
    prediction += bst.predict(test[features])
    eval_pre = bst.predict(train[features].loc[eval_index])
    score = np.sqrt(mean_squared_error(train[label].loc[eval_index].values, eval_pre))
    cv_score.append(score)
print(cv_score, sum(cv_score)/5)
submission = test[["card_id"]].copy()
submission["target"] = [p/5 for p in list(prediction)]
submission.to_csv("result/LGB_FeatureSelect_submission.csv", index=False)