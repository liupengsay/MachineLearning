##version_6基础上采用logloss作为早停依据+转化率统计
version = 'version_10'
import os
import sys
os.system('pip install -U scikit-learn')
os.system('pip install tables')
os.system('pip install lightgbm')
sys.path.append('/cos_person/KDD/')
class Unbuffered(object):
    def __init__(self, stream):
        self.stream = stream

    def write(self, data):
        self.stream.write(data)
        self.stream.flush()

    def __getattr__(self, attr):
        return getattr(self.stream, attr)
sys.stdout = Unbuffered(sys.stdout)
path =  '/cos_person/KDD/'

import pandas as pd
import numpy as np
import os
import time
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import roc_auc_score
import lightgbm as lgb
import gc
import json
from sklearn.model_selection import KFold
import warnings
warnings.filterwarnings("ignore")
print('reading')
########################
label = pd.read_csv(path+'data_set_phase1/train_clicks.csv')
print(label.shape)
se = label['click_mode'].value_counts()
print('label distribution')
print(se/se.sum())
se  = label['sid'].value_counts()
print('sid count describe')
print(se.describe())
print('click min',label['click_time'].min())
print('click max',label['click_time'].max())
########################
profile = pd.read_csv(path+'data_set_phase1/profiles.csv')
features = ['p'+str(i) for i in range(66)]
profile[features] = profile[features].astype(np.int8)
print(profile.shape)
print('number of different pid:',profile['pid'].nunique())
########################
file_queries_train = path+'data_set_phase1/train_queries.csv'
file_plans_train = path+'data_set_phase1/train_plans.csv'

file_queries_test = path+'data_set_phase1/test_queries.csv'
file_plans_test = path+'data_set_phase1/test_plans.csv'

def getData(file_queries,file_plans):
    query = pd.read_csv(file_queries)
    plan = pd.read_csv(file_plans)
    se = pd.Series(query['sid'].values).map(pd.Series(1,index = plan['sid'].values))
    query['no_plan'] = query['sid'].map(pd.Series(1,index=query['sid'][se!=1].values)).fillna(0)
    ##特征工程转换表格形式
    lst = []
    for lab in label['click_mode'].drop_duplicates().sort_values().values.tolist():
        for fea in ['distance','eta', 'price','transport_mode','transport_mode_rank']:
            lst.append(fea+'_'+str(lab))
    lst.append('len_mode')
    lst.append('transport_mode_first')
    features = pd.Series(lst)
    def getLst(va):
        va = json.loads(va)
        dct = {}
        for i in range(len(va)):
            lab = int(va[i]['transport_mode'])
            if i==0:
                dct['transport_mode_first'] = lab
            for fea in ['distance','eta', 'price']:
                if len(str(va[i][fea]))>0:
                    dct[fea+'_'+str(lab)] = va[i][fea]
            dct['transport_mode_rank'+'_'+str(lab)] = i+1
            dct['transport_mode'+'_'+str(lab)] = 1
        dct['len_mode'] = len(va)
        return features.map(pd.Series(dct)).fillna(-1).astype(int).values.tolist()
    plan = pd.concat([plan,pd.DataFrame(plan['plans'].apply(getLst).values.tolist(),
                                        columns = features.values.tolist())],axis=1)
    del plan['plans']
    
    
    plan['hour'] = plan['plan_time'].apply(lambda x:int((x.split(' ')[1]).split(':')[0]))
    plan['day'] = plan['plan_time'].apply(lambda x:int((x.split(' ')[0]).split('-')[-1]))
    plan['month'] = plan['plan_time'].apply(lambda x:int((x.split(' ')[0]).split('-')[1]))
    def getWday(x):
        timeArray = time.strptime(x, "%Y-%m-%d %H:%M:%S")
        return timeArray .tm_wday
    plan['wday'] = plan['plan_time'].apply(getWday)
    
    plan = pd.merge(query,plan,how='left',on='sid')
    plan['pid'] = plan['pid'].fillna(-1).astype(int)
    def getStamp(x):
        try:
            timeArray = time.strptime(x, "%Y-%m-%d %H:%M:%S")
            timeStamp = int(time.mktime(timeArray))
            return timeStamp
        except:
            return np.nan
    plan['plan_req_gap'] = plan['plan_time'].apply(getStamp)-plan['req_time'].apply(getStamp)
    plan['plan_time_stamp'] = plan['plan_time'].apply(getStamp)
    del plan['req_time']
    del plan['plan_time']

    plan['o0'] = plan['o'].apply(lambda x:float(x.split(',')[0]))
    plan['o1'] = plan['o'].apply(lambda x:float(x.split(',')[1]))
    plan['d0'] = plan['d'].apply(lambda x:float(x.split(',')[0]))
    plan['d1'] = plan['d'].apply(lambda x:float(x.split(',')[1]))

    del plan['o']
    del plan['d']
    plan['dis'] = (plan['o0']-plan['d0'])**2+(plan['o1']-plan['d1'])**2
    plan['dis_abs'] = (plan['o0']-plan['d0']).abs()+(plan['o1']-plan['d1']).abs()
    plan = pd.merge(plan,profile,how='left',on='pid')
    cols =  ['p'+str(i) for i in range(66)]
    plan[cols] = plan[cols].fillna(-1).astype(np.int8)
    return plan

try:
    train_x = pd.read_csv(path+'preprocess/'+version+'_train.csv')
    test_x = pd.read_csv(path+'preprocess/'+version+'_test.csv')
    train_y = pd.read_csv(path+'preprocess/'+version+'_trainy.csv')[['click_mode']]
except:
    train_x = getData(file_queries_train,file_plans_train)
    test_x = getData(file_queries_test,file_plans_test)
    train_x.to_csv(path+'preprocess/'+version+'_train.csv',index=False)
    test_x.to_csv(path+'preprocess/'+version+'_test.csv',index=False)
    train_y = pd.merge(train_x,label,how='left',on='sid')[['click_mode']].fillna(0).astype(np.int8)
    train_y.to_csv(path+'preprocess/'+version+'_trainy.csv',index=False)



m = train_x.shape[0]  

train_x['target'] = train_y.values
test_x['target']=-1
data = pd.concat([train_x,test_x],axis=0,ignore_index=True)
labels = label['click_mode'].drop_duplicates().sort_values().values.tolist()
##########################
for fea in ['distance','eta', 'price']:
    dt = data[[fea+'_'+str(lab) for lab in labels]].replace(-1,np.nan)
    data[fea+'_max'] = dt.max(1)
    data[fea+'_min'] = dt.min(1)
    data[fea+'_mean'] = dt.mean(1)
    data[fea+'_std'] = dt.std(1)
##########################



del train_x
del test_x
gc.collect()
#####cvr###
type_feature = ['o0','o1','d0','d1','hour','day','wday','pid','month']
train_index = data[:m].index.tolist()


def get_cvr_smooth_feature_total(type_feature,num_label):
    data['label'] = (data['target']==num_label).astype(int)-(data['target']==-1).astype(int)
    from smooth import HyperParam
    from sklearn.model_selection import StratifiedKFold
    train = data.loc[train_index]
    train_y_ = train['label']
    n = len(type_feature)
    df_ = pd.DataFrame()
    #######################
    n_parts = 6
    skf = StratifiedKFold(n_splits=n_parts-1,random_state=20,shuffle=True)
    data['n_parts'] = -1
    num = 1
    for trainIndex,testIndex in skf.split(train,train_y_):
        data.loc[testIndex,'n_parts'] = num
        num+=1
    data.loc[data['label']==-1,'n_parts']=6
    #####################
    rate = [1,1,1,1,1,0.8]
    ###################
    for co in type_feature:
        col_name = 'cvr_of_'+co
        se =pd.Series()
        hp1 = []
        hp2 = []
        for k in range(1,n_parts+1):
            df = data[data['n_parts']==k][[co]]
            temp = data[(data['n_parts']!=k)&(data['label']>=0)][[co,'label']].groupby(co)['label'].agg({co + '_click': 'sum', co + '_count': 'count'})
            # smooth
            temp[co + '_count'] = temp[co + '_count']*rate[k-1]
            temp[co + '_click'] = temp[co + '_click']*rate[k-1]
            hp1.extend(temp[co + '_count'].values.tolist())
            hp2.extend(temp[co + '_click'].values.tolist())
        HP = HyperParam(1, 1)
        HP.update_from_data_by_moment(np.array(hp1), np.array(hp2))
        a = HP.alpha
        b = HP.beta
        
        for k in range(1,n_parts+1):
            df = data[data['n_parts']==k][[co]]
            temp = data[(data['n_parts']!=k)&(data['label']>=0)][[co,'label']].groupby(co)['label'].agg({co + '_click': 'sum', co + '_count': 'count'})
            # smooth
            temp[co + '_count'] = temp[co + '_count']*rate[k-1]
            temp[co + '_click'] = temp[co + '_click']*rate[k-1]
            temp[co + '_ctr_smooth'] = (temp[co + '_click'] + a) / (
                    temp[co + '_count'] + a+b)           
            se = se.append(pd.Series(df[co].map(temp[co + '_ctr_smooth']).values, index = df.index))
        df_[col_name+'_smooth'] = pd.Series(data.index).map(se)
        
        
    for i in range(n):
        for j in range(n-i-1):
            col_name = 'cvr2_of_'+type_feature[i]+"_and_"+type_feature[i+j+1]
            se = pd.Series()
            hp1 = []
            hp2 = []
            for k in range(1,n_parts+1):               
                temp = data[(data['n_parts']!=k)&(data['label']>=0)].groupby([type_feature[i],type_feature[i+j+1]])['label'].agg({col_name + '_click': 'sum', col_name + '_count': 'count'})
                temp[col_name + '_count'] = temp[col_name + '_count']*rate[k-1]
                temp[col_name + '_click'] = temp[col_name + '_click']*rate[k-1]
                hp1.extend(temp[col_name + '_count'].values.tolist())
                hp2.extend(temp[col_name + '_click'].values.tolist())
            # smooth
            HP = HyperParam(1, 1)
            HP.update_from_data_by_moment(np.array(hp1), np.array(hp2))
            a = HP.alpha
            b = HP.beta
            for k in range(1,n_parts+1):               
                temp = data[(data['n_parts']!=k)&(data['label']>=0)].groupby([type_feature[i],type_feature[i+j+1]])['label'].agg({col_name + '_click': 'sum', col_name + '_count': 'count'})

                temp[col_name + '_count'] = temp[col_name + '_count']*rate[k-1]
                temp[col_name + '_click'] = temp[col_name + '_click']*rate[k-1]
                temp[col_name + '_ctr_smooth'] = (temp[col_name + '_click'] + a) / (
                        temp[col_name + '_count'] + a+b)
                dt = data[data['n_parts']==k][[type_feature[i],type_feature[i+j+1]]]
                dt.insert(0,'index',list(dt.index))
                dt = pd.merge(dt,temp[col_name + '_ctr_smooth'].reset_index(),how='left',on=[type_feature[i],type_feature[i+j+1]])
                se = se.append(pd.Series(dt[col_name + '_ctr_smooth'].values,index=list(dt['index'].values)))
            df_[col_name+'_smooth'] = pd.Series(data.index).map(se).values
    del data['n_parts']
    del data['label']
    return df_
print('cvr...')
for num_label in range(12):
    df = get_cvr_smooth_feature_total(type_feature,num_label)
    data = pd.concat([data,df],axis=1)
    del df
del data['target']
#################  常规一二阶统计 ######################
data['cnt'] = 1
n = len(type_feature)
s = time.time()
print('ratio...')
for i in range(n):
    cnt = data[type_feature[i]].map(data[type_feature[i]].value_counts())
    for j in range(n):
        if i!=j:
            col_name = "ratio_click_of_"+type_feature[j]+"_in_"+type_feature[i]
            se = data.groupby([type_feature[i],type_feature[j]])['cnt'].sum()
            dt = data[[type_feature[i],type_feature[j]]]
            data[col_name] = ((pd.merge(dt,se.reset_index(),how='left',on=[type_feature[i],type_feature[j]]).sort_index()['cnt']/cnt)*100).fillna(value=0).astype(np.int8).values
print(time.time()-s,'s')
s = time.time()
print('cnt...')
for i in range(n):
    col_name = "cnt_click_of_"+type_feature[i]
    se = data[type_feature[i]].map(data[type_feature[i]].value_counts()).fillna(value=0)
    se = (((se-se.min())/(se.max()-se.min()))*100).fillna(0).astype(np.int8)
    data[col_name] = se.values
for i in range(n):
    for j in range(n-i-1):
        col_name = "cnt_click_of_"+type_feature[i+j+1]+"_and_"+type_feature[i]
        se = data.groupby([type_feature[i],type_feature[i+j+1]])['cnt'].sum()
        dt = data[[type_feature[i],type_feature[i+j+1]]]
        se = (pd.merge(dt,se.reset_index(),how='left',
                        on=[type_feature[i],type_feature[j+i+1]]).sort_index()['cnt'].fillna(value=0)).astype(int)
        se = (((se-se.min())/(se.max()-se.min()))*100).fillna(0).astype(np.int8)
        data[col_name] = se.values
print(time.time()-s,'s')
s = time.time()
print('nunique...')
for i in range(n):
    for j in range(n):
        if i!=j:
            col_name = "count_type_"+type_feature[j]+"_in_"+type_feature[i]
            s = time.time()      
            se = data.groupby([type_feature[i]])[type_feature[j]].value_counts()
            se = pd.Series(1,index=se.index).sum(level=type_feature[i])
            se = data[type_feature[i]].map(se)
            se = (((se-se.min())/(se.max()-se.min()))*100).fillna(0).astype(np.int8)
            data[col_name] = se.values
del data['cnt']
print(time.time()-s,'s')
s = time.time()
################### mean特征生成   ################### 
print('mean...')
s = time.time()
num = 0
for lab in ['p'+str(i) for i in range(66)]:
    for typ in type_feature:
        data['mean_of_'+lab+'_in_'+typ] = ((data[typ].map(data.groupby(typ)[lab].mean()))*100).fillna(-1).astype(np.int8)  
        num+=1
        if num%100==0:
            print(num,time.time()-s,'s')
            s = time.time()
train_x = data[:m]
test_x =  data[m:].reset_index(drop=True)
del data
gc.collect()


del train_x['sid']
res = test_x[['sid']]

train_y = pd.Series(train_y[train_x['no_plan']==0]['click_mode'].values)
train_x = train_x[train_x['no_plan']==0].reset_index(drop=True)

sub1 = test_x[test_x['no_plan']==1][['sid']]
sub1['recommend_mode'] = 0

test_x = test_x[test_x['no_plan']==0].reset_index(drop=True)
sub2 = test_x[['sid']]
del test_x['sid']
del train_x['no_plan']
del test_x['no_plan']

num_class = 12
params_default_lgb = {
        'num_leaves':31, 
        'learning_rate':0.01, 
    'boosting':'gbdt',
    'min_child_samples':20,

    'bagging_fraction':1, 
    'bagging_freq':1,
    'feature_fraction':1, 
     'max_depth':-1,
    'reg_alpha':0,
    'reg_lambda':0, 
    'objective':'multiclass',
    'num_class':num_class
}

NBR = 20000
VBE = 100
ESR = 30
from sklearn.metrics import f1_score
def f1_score_vali(preds, data_vali):
    labels = data_vali.get_label()
    preds = np.argmax(preds.reshape(num_class, -1), axis=0)
    score_vali = f1_score(y_true=labels, y_pred=preds, average='weighted')
    return 'f1_score', score_vali, True
from sklearn.model_selection import StratifiedKFold

def getBestCut(ypre):
    score = []
    for cut in range(1,100):
        score.append(f1_score(train_y_.loc[evals_index].values,(pd.Series(ypre)>=cut*0.01).astype(int).values))
    return np.array(score).max()
#cols = train_x.columns.tolist()
# for i in range(num_class):
#     train_y_ = (train_y==i).astype(int)
#     params_binary_lgb = {
#         'num_leaves':31, 
#         'learning_rate':0.01, 
#     'boosting':'gbdt',
#     'min_child_samples':20,

#     'bagging_fraction':1, 
#     'bagging_freq':1,
#     'feature_fraction':1, 
#      'max_depth':-1,
#     'reg_alpha':0,
#     'reg_lambda':0, 
#     'objective':'binary'
#         }
    
#     se = pd.Series()
#     arr = 0
#     fscore = []
#     skf = StratifiedKFold(n_splits=5,random_state=i,shuffle=True)
#     ESR = 100
#     for train_part_index,evals_index in skf.split(train_x[cols],train_y_):
#         train_part = lgb.Dataset(train_x[cols].loc[train_part_index],label=train_y_.loc[train_part_index])
#         evals = lgb.Dataset(train_x[cols].loc[evals_index],label=train_y_.loc[evals_index])
#         bst = lgb.train(params_binary_lgb,train_part, 
#               num_boost_round=NBR, valid_sets=[train_part,evals],
#               valid_names=['train','evals'],early_stopping_rounds=ESR,verbose_eval=VBE)
#         arr = arr+bst.predict(test_x[cols])
#         ypre = bst.predict(train_x[cols].loc[evals_index])
#         se = se.append(pd.Series(ypre,index=evals_index))
#         fscore.append(getBestCut(ypre))
#         print(fscore)
#         print(np.array(fscore).mean())
        
#     train_x['binary_'+str(i)] = se.sort_index().values
#     test_x['binary_'+str(i)] = arr/5


print(train_x.shape)
print(test_x.shape)
from sklearn.metrics import f1_score
def f1_score_vali(preds, data_vali):
    labels = data_vali.get_label()
    preds = np.argmax(preds.reshape(num_class, -1), axis=0)
    score_vali = f1_score(y_true=labels, y_pred=preds, average='weighted')
    return 'f1_score', score_vali, True
from sklearn.model_selection import StratifiedKFold
ESR = 1000
arr = 0
rmse = []
skf = StratifiedKFold(n_splits=5,random_state=2018,shuffle=True)
for train_part_index,evals_index in skf.split(train_x,train_y):
    EVAL_RESULT = {}
    train_part = lgb.Dataset(train_x.loc[train_part_index],label=train_y.loc[train_part_index])
    evals = lgb.Dataset(train_x.loc[evals_index],label=train_y.loc[evals_index])
    bst = lgb.train(params_default_lgb,train_part, evals_result=EVAL_RESULT,
          num_boost_round=NBR, valid_sets=[train_part,evals],feval=f1_score_vali,
          valid_names=['train','evals'],early_stopping_rounds=ESR,verbose_eval=VBE)
    lst = EVAL_RESULT['evals']['f1_score']
    best_score = max(lst)
    print(best_score)
    best_iter = lst.index(best_score)+1
    arr = arr+bst.predict(test_x,num_iteration = best_iter)
    rmse.append(best_score)
    print(rmse)
    print(np.array(rmse).mean())
    sub2['recommend_mode'] = [va.argmax() for va in arr]
    pd.merge(res,pd.concat([sub1,sub2],axis=0,ignore_index=True),how='left',on='sid').to_csv(path+'result/'+version+'.csv',index=False)
#print('binary:',i,'Done')
print('\n')
print('\n')
print('\n')
print('\n')