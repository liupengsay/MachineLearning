import numpy as np
import pandas as pd
import lightgbm as lgb
from sklearn.model_selection import KFold
from sklearn.metrics import mean_squared_error
train = pd.read_csv("preprocess/baseline_train.csv")
test = pd.read_csv("preprocess/baseline_test.csv")
label = "target"
features = train.columns.tolist()
features.remove('card_id')
features.remove('target')
train_data = lgb.Dataset(train[features], train[label], silent=True)


params_best = {'bagging_fraction': 0.9867972905115349, 'bagging_freq': 2, 'feature_fraction': 0.5001463161928636, 'learning_rate': 0.007579965828642041, 'max_depth': 11, 'min_child_samples': 1, 'num_leaves': 11, 'reg_alpha': 9.962793686525739, 'reg_lambda': 0.31896100731890176}# [3.7019118736151246, 3.6609627107627642, 3.7206494952216933, 3.7975632214160884, 3.5868021730377624] 3.693577894810687

def params_append(params):
    params['objective'] = 'regression'
    params['metric'] = 'rmse'
    params['bagging_seed'] = 2020
    return params
params_best = params_append(params_best)
kf = KFold(n_splits=5, random_state=2020, shuffle=True)
prediction = 0
cv_score = []
ESR = 30
NBR = 10000
VBE = 50
testarr = 0
trainse = pd.Series()
for train_part_index, eval_index in kf.split(train[features], train[label]):
    # 模型训练
    train_part = lgb.Dataset(train[features].loc[train_part_index],
                             train[label].loc[train_part_index])
    eval = lgb.Dataset(train[features].loc[eval_index],
                       train[label].loc[eval_index])
    bst = lgb.train(params_best, train_part, num_boost_round=NBR,
                    valid_sets=[train_part, eval],
                    valid_names=['train', 'valid'],
                    early_stopping_rounds=ESR, verbose_eval=VBE)
    prediction += bst.predict(test[features])
    eval_pre = bst.predict(train[features].loc[eval_index])
    testarr += bst.predict(test[features])
    trainse = trainse.append(pd.Series(bst.predict(train[features].loc[eval_index]), index=eval_index))
    score = np.sqrt(mean_squared_error(train[label].loc[eval_index].values, eval_pre))
    cv_score.append(score)
pd.Series(trainse.sort_index().values).to_csv("preprocess/train_stack.csv", index=False)
pd.Series(testarr/5).to_csv("preprocess/test_stack.csv", index=False)

