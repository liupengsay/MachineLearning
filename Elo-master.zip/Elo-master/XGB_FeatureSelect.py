import xgboost as xgb
import pandas as pd
import numpy as np
from sklearn.model_selection import KFold
from sklearn.metrics import mean_squared_error
# 采用stacking进行降维？
train = pd.read_csv('preprocess/baseline_train_plus.csv')
test = pd.read_csv('preprocess/baseline_test_plus.csv')
params_initial = {
        'max_depth':6,
        'eta':0.1,
    'booster':'gbtree',
  'min_child_weight':1,
    'subsample':0.8,
    'colsample_bytree':0.8,
    'reg_alpha':0,
    'reg_lambda':1,
    'seed':2020,
    'eval_metric':'rmse',
    'objective':'reg:squarederror',
}
ESR = 30
NBR = 10000
VBE = 50
# 读取特征重要性
fse = pd.read_csv('result/baseline_feature_importance_plus.csv')\
       .sort_values('importance', ascending=False)
cols = fse['feature'].values.tolist()
label = 'target'
lst = []
for num in list(range(50, 200, 10))+[len(cols)]:
       features = cols[:num]
       data_train = xgb.DMatrix(train[features], train[label], silent=True)
       cv_results = xgb.cv(params_initial,
                                   data_train,
                                   num_boost_round=1000,
                                   nfold=5,
                                   stratified=False,
                                   shuffle=True,
                                   metrics=['rmse'],
                                   early_stopping_rounds=50,
                                   verbose_eval=False,
                                   show_stdv=False,
                                   seed=0)
       lst.append(cv_results['test-rmse-mean'].min())
       print(num, 'best cv score:', cv_results['test-rmse-mean'].min())

score_lst = pd.Series(lst[:-1], index=range(50, 200, 10))\
       .sort_values()
numFeatureSelect = score_lst.index[0]
print(numFeatureSelect, score_lst.values[0])

numFeatureSelect = 190
# 190 3.70817358070979
features = cols[:numFeatureSelect]
pd.Series(features).to_csv('preprocess/xgb_select_feature_plus.csv', index=False)

kf = KFold(n_splits=5, random_state=2020, shuffle=True)
prediction = 0
cv_score = []
test_data = xgb.DMatrix(test[features])
for train_part_index, eval_index in kf.split(train[features], train[label]):
    # 模型训练
    train_part = xgb.DMatrix(train[features].loc[train_part_index],
                             train[label].loc[train_part_index])
    eval = xgb.DMatrix(train[features].loc[eval_index],
                             train[label].loc[eval_index])
    bst = xgb.train(params_initial, train_part, NBR, [(train_part, 'train'),
                                                      (eval, 'eval')], verbose_eval=VBE,
                    maximize=False, early_stopping_rounds=ESR, )
    prediction += bst.predict(test_data)
    eval_pre = bst.predict(eval)
    score = np.sqrt(mean_squared_error(train[label].loc[eval_index].values, eval_pre))
    cv_score.append(score)
print(cv_score, sum(cv_score)/5)
submission = test[["card_id"]].copy()
submission["target"] = [p/5 for p in list(prediction)]
submission.to_csv("result/XGB_FeatureSelect_submission_plus.csv", index=False)