import lightgbm as lgb
from bayes_opt import BayesianOptimization
import numpy as np
import pandas as pd
import xgboost as xgb
from sklearn.model_selection import KFold
from sklearn.metrics import mean_squared_error

train = pd.read_csv("preprocess/baseline_train_plus.csv")
test = pd.read_csv("preprocess/baseline_test_plus.csv")
label = "target"
featureSelect = pd.read_csv("preprocess/XGB_select_feature_plus.csv", header=None)[0].values.tolist()
features = ["card_id"] + featureSelect + [label]
train = train[features]
test = test[features[:-1]]
features = featureSelect.copy()
train_data = xgb.DMatrix(train[features], train[label], silent=True)
test_data = xgb.DMatrix(test[features])
def xgb_cv(colsample_bytree, subsample, min_child_weight, max_depth,
           reg_alpha, eta,
           reg_lambda):
    params = {'objective': 'reg:squarederror',
              'early_stopping_round': 50, 
              'eval_metric': 'rmse'}
    params['colsample_bytree'] = max(min(colsample_bytree, 1), 0)
    params['subsample'] = max(min(subsample, 1), 0)
    params["min_child_weight"] = int(min_child_weight)
    params['max_depth'] = int(max_depth)
    params['eta'] = int(eta)
    params['reg_alpha'] = max(reg_alpha, 0)
    params['reg_lambda'] = max(reg_lambda, 0)

    cv_result = xgb.cv(params, train_data,
                       num_boost_round=1000,
                       nfold=5, seed=2,
                       stratified=False,
                       shuffle=True,
                       early_stopping_rounds=30,
                       verbose_eval=False)
    return -min(cv_result['test-rmse-mean'])
def params_append(params):
    params['objective'] = 'reg:squarederror'
    params['eval_metric'] = 'rmse'
    params["min_child_weight"] = int(params["min_child_weight"])
    params['max_depth'] = int(params['max_depth'])
    return params

xgb_bo = BayesianOptimization(
    xgb_cv,
    {'colsample_bytree': (0.5, 1),
     'subsample': (0.5, 1),
     'min_child_weight': (1, 100),
     'max_depth': (3, 15),
     'reg_alpha': (0, 10),
     'eta':(0.01, 0.5),
     'reg_lambda': (0, 10)}
)
def train_predict(params):
    params = params_append(params)
    kf = KFold(n_splits=5, random_state=2020, shuffle=True)
    prediction = 0
    cv_score = []
    ESR = 30
    NBR = 10000
    VBE = 50
    for train_part_index, eval_index in kf.split(train[features], train[label]):
        # 模型训练
        train_part = xgb.DMatrix(train[features].loc[train_part_index],
                                 train[label].loc[train_part_index])
        eval = xgb.DMatrix(train[features].loc[eval_index],
                           train[label].loc[eval_index])
        bst = xgb.train(params, train_part, NBR, [(train_part, 'train'),
                                                          (eval, 'eval')], verbose_eval=VBE,
                        maximize=False, early_stopping_rounds=ESR, )
        prediction += bst.predict(test_data)
        eval_pre = bst.predict(eval)
        score = np.sqrt(mean_squared_error(train[label].loc[eval_index].values, eval_pre))
        cv_score.append(score)
    print(cv_score, sum(cv_score) / 5)
    submission = test[["card_id"]].copy()
    submission["target"] = [p / 5 for p in list(prediction)]
    submission.to_csv("result/XGB_ParamSearch_submission_plus.csv", index=False)
    return
xgb_bo.maximize(init_points=21, n_iter=50)  # init_points表示初始点，n_iter代表迭代次数（即采样数）
print(xgb_bo.max['target'], xgb_bo.max['params'])
train_predict(xgb_bo.max['params'])

