import pandas as pd
path =  '/cos_person/KDD/'
file = [
    path+'result/version_10-submission-bainary-'+str(i)+'.csv' for i in range(12)
]
df = pd.DataFrame()
for i in range(len(file)):
    df[i] = pd.read_csv(file[i])['recommend_mode']
    print(file[i])
print(df.head())

sub = pd.read_csv(file[i])
def getTarget(lst):
    se = pd.Series(lst).value_counts()
    return se.index[0]
sub['recommend_mode'] = df.apply(getTarget,axis=1)
print(sub['recommend_mode'].value_counts())
sub.to_csv(path+'result/lp_submission_0430_version_10.csv',index=False)