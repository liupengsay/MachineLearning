import pandas as pd
import numpy as np
from sklearn.metrics import mean_squared_error
from sklearn.model_selection import KFold
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import GridSearchCV

train = pd.read_csv("preprocess/baseline_train.csv")
test = pd.read_csv("preprocess/baseline_test.csv")

label = "target"
featureSelect = pd.read_csv("preprocess/RF_select_feature.csv", header=None)[0].values.tolist()

features = ["card_id"] + featureSelect + [label]

train = train[features].fillna(0)
test = test[features[:-1]].fillna(0)


# parameter_space = {
#     "n_estimators": [50, 60],
#     "min_samples_leaf": [1, 3],
#     "min_samples_split" : [2, 5],
#     "max_depth": [5, 7]
# }

parameter_space = {
    "n_estimators": [60, 70, 80],
    "min_samples_leaf": [20, 30, 40, 50],
    "min_samples_split" : [2],
    "max_depth": [11, 13, 15, 17],
    "max_features": ["auto", 80, 120, 150]
}



print("Tuning hyper-parameters for mse")
clf = RandomForestRegressor(
    criterion="mse",
    min_weight_fraction_leaf=0.,
    max_leaf_nodes=None,
    min_impurity_decrease=0.,
    min_impurity_split=None,
    bootstrap=True,
    oob_score=False,
    n_jobs=4,
    random_state=2020,
    verbose=0,
    warm_start=False)
grid = GridSearchCV(clf, parameter_space, cv=5, scoring="neg_mean_squared_error")

grid.fit(train[featureSelect].values, train[label].values)

print("Best parameters set found on development set:")
print()
print(grid.best_params_)
print()
print("Grid scores on development set:")
print()

means = grid.cv_results_["mean_test_score"]
stds = grid.cv_results_["std_test_score"]
for mean, std, params in zip(means, stds, grid.cv_results_["params"]):
    print("%0.3f (+/-%0.03f) for %r"
          % (mean, std * 2, params))
print()
print("Detailed classification report:")
print()
print("The model is trained on the full development set.")
print("The scores are computed on the full evaluation set.")
print()


prediction = 0
cv_score = []
kf = KFold(n_splits=5, random_state=2020, shuffle=True)
for train_part_index, eval_index in kf.split(train[featureSelect], train[label]):
    best_clf = grid.best_estimator_
    best_clf.fit(train[featureSelect].loc[train_part_index].values, train[label].loc[train_part_index].values)
    prediction += best_clf.predict(test[featureSelect].values)
    eval_pre = best_clf.predict(train[featureSelect].loc[eval_index].values)
    score = np.sqrt(mean_squared_error(train[label].loc[eval_index].values, eval_pre))
    cv_score.append(score)
    print(score)
print(cv_score, sum(cv_score)/5)
#
# [3.729402448701223, 3.692953326189988, 3.739713545493223, 3.827379741411834, 3.6124011724941103]
# 3.720370046858
# {'max_depth': 17, 'max_features': 80, 'min_samples_leaf': 30, 'min_samples_split': 2, 'n_estimators': 80}
# [3.7131163345487317, 3.682380355959514, 3.7359900520312332, 3.813170573696684, 3.6031910589337763]
# 3.7095696750339884
submission = test[["card_id"]].copy()
submission["target"] = [p/5 for p in list(prediction)]
submission.to_csv("result/RF_ParamSearch_submission.csv", index=False)